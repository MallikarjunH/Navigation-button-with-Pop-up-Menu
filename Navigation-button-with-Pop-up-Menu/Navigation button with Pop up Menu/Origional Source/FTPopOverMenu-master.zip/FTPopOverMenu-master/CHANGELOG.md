# FTPopOverMenu


| Version | Date | ChangeLog |
|:--------:|:--------:|:--------|
|1.0.0|2016-04-03| upload to CocoaPods|
|1.1.5|2016-08-04| fix a bug (arrowPoint.x)|
|1.1.6|2016-08-15| fix an issue of out of screen when too many menus|
|1.1.7|2016-08-22| fix an issue thanks to Cui Lizong|
|1.1.8|2016-08-25| add custom width support|
|1.1.9|2016-08-26| add custom text color support|
|1.2.0|2016-09-07| fix some bugs|
|1.2.1|2016-09-15| Big Change: more customizable|
|1.2.2|2016-10-12| fix a bug of customize height|
|1.2.3|2016-11-17| remove last cell's separator, now looks more clean|
|1.2.5|2016-11-24| add some more animations|
|1.2.6|2016-12-07| Menu text and icon margins can be configured via FTPopOverMenuConfiguration.|
|1.3.0|2016-12-21| Big jump. It supports more image resource, such as local UIImage, bundle image name, remote image url. I just changed almost all of the APIs, and still kept the old APIs working. |
|1.3.1|2016-12-21| fix bug: image cache name encode |
|1.3.2|2017-01-07| added round arrow support |
|1.3.3|2017-03-05| remove some unused methods |
|1.3.4|2018-01-26| add selected text color and cell background color |




